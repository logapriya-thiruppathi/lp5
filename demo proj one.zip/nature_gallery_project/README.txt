Nature Gallery — 3-page project
Files:
- index.html (home with gallery + carousel + lightbox + filter)
- about.html
- contact.html (demo client-side form)
- css/style.css
- js/main.js

Enhancements included:
1. Accessible lightbox (keyboard: Escape to close)
2. Manual carousel (no autoplay)
3. Client-side filtering of gallery
4. Sticky header/footer and theme toggle (dark mode)

Images load from Unsplash (remote URLs) and include alt text.

To run: open index.html in a browser. This project is packaged for submission.
