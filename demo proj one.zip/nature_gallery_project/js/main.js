// main.js - JavaScript enhancements: filtering, lightbox, carousel, theme toggle, form validation

document.addEventListener('DOMContentLoaded', function () {
  // Accessibility: focus main on load
  const main = document.getElementById('main') || document.getElementById('main-about') || document.getElementById('main-contact')
  if(main) main.focus();

  // Theme toggle (applies to body)
  function setupThemeToggle(btnId) {
    const btn = document.getElementById(btnId);
    if(!btn) return;
    btn.addEventListener('click', ()=> {
      const on = document.body.classList.toggle('dark');
      btn.setAttribute('aria-pressed', String(on));
    });
  }
  setupThemeToggle('theme-toggle');
  setupThemeToggle('theme-toggle-about');
  setupThemeToggle('theme-toggle-contact');

  // Filter gallery
  const filter = document.getElementById('filter');
  if(filter){
    filter.addEventListener('change', (e)=>{
      const val = e.target.value;
      const cards = document.querySelectorAll('.gallery .card');
      cards.forEach(card=>{
        const cat = card.getAttribute('data-category');
        if(val === 'all' || val === cat) card.style.display = '';
        else card.style.display = 'none';
      });
    });
  }

  // Lightbox
  const lightbox = document.getElementById('lightbox');
  const lbImg = document.getElementById('lb-img');
  const lbCaption = document.getElementById('lb-caption');
  const lbClose = document.getElementById('lb-close');

  document.querySelectorAll('.thumb').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      const full = btn.getAttribute('data-full');
      const alt = btn.querySelector('img')?.alt || '';
      lbImg.src = full;
      lbImg.alt = alt;
      lbCaption.textContent = alt;
      lightbox.setAttribute('aria-hidden','false');
      lbClose.focus();
    });
  });

  lbClose.addEventListener('click', ()=>{
    lightbox.setAttribute('aria-hidden','true');
    lbImg.src = '';
  });

  // close lightbox on escape
  document.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape' && lightbox.getAttribute('aria-hidden') === 'false'){
      lightbox.setAttribute('aria-hidden','true');
      lbImg.src = '';
    }
  });

  // Carousel manual controls (no autoplay)
  (function(){
    const track = document.getElementById('track');
    if(!track) return;
    const slides = Array.from(track.querySelectorAll('.slide'));
    let current = 0;
    function show(i){
      slides.forEach((s,idx)=>{
        s.hidden = idx !== i;
      });
    }
    document.getElementById('prev').addEventListener('click', ()=>{
      current = (current - 1 + slides.length) % slides.length;
      show(current);
    });
    document.getElementById('next').addEventListener('click', ()=>{
      current = (current + 1) % slides.length;
      show(current);
    });
    // keyboard support
    document.getElementById('prev').addEventListener('keydown', (e)=>{ if(e.key==='Enter') e.target.click() });
    document.getElementById('next').addEventListener('keydown', (e)=>{ if(e.key==='Enter') e.target.click() });
    show(current);
  })();

  // Contact form client-side validation demo
  const form = document.getElementById('contact-form');
  if(form){
    const status = document.getElementById('form-status');
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const name = form.name.value.trim();
      const email = form.email.value.trim();
      const message = form.message.value.trim();
      let ok = true;
      if(name.length < 2){ ok = false; form.name.setAttribute('aria-invalid','true') } else form.name.removeAttribute('aria-invalid');
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ ok = false; form.email.setAttribute('aria-invalid','true') } else form.email.removeAttribute('aria-invalid');
      if(message.length < 5){ ok = false; form.message.setAttribute('aria-invalid','true') } else form.message.removeAttribute('aria-invalid');
      if(!ok){ status.textContent = 'Please fix the highlighted fields.'; return; }
      status.textContent = 'Thanks — this demo does not send messages, but would in a real site.';
      form.reset();
    });
  }

});